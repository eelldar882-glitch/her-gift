/* =========================================================
   For Her — script.js
   ========================================================= */

/* ---------------------------------------------------------
   🎵 تنظیمات آهنگ — فقط همین بخش را ویرایش کن
   ---------------------------------------------------------
   src:    مسیر فایل MP3 (مثلاً "music/song.mp3") یا یک لینک مستقیم
           به فایل صوتی. اگر خالی ("") باشد، سایت بدون خطا کار می‌کند.
   title:  اسم آهنگ
   artist: اسم خواننده
--------------------------------------------------------- */
const SONG = {
  src: "music/song.mp3",
  title: "Beresoon Khodeto",
  artist: "The Don"
};

/* =========================================================
   از اینجا به بعد نیازی به تغییر نیست
   ========================================================= */
(function () {
  "use strict";

  var pages    = Array.prototype.slice.call(document.querySelectorAll(".page"));
  var dots     = Array.prototype.slice.call(document.querySelectorAll("#progress .dot"));
  var counter  = document.getElementById("counter");
  var current  = 0;
  var observer = null;

  /* ---------- Navigation ---------- */
  function goTo(index) {
    if (index < 0 || index >= pages.length || index === current) return;

    pages[current].classList.remove("active");
    current = index;

    var page = pages[current];
    page.scrollTop = 0;
    page.classList.add("active");

    dots.forEach(function (d, i) { d.classList.toggle("active", i === current); });
    counter.textContent = "0" + (current + 1);

    if (current === 0) {
      resetReveals();
      stopMusic();
    }
    watchReveals(page);
  }

  function next()  { goTo(current + 1); }
  function first() { goTo(0); }

  /* دکمه‌ها (ENTER / NEXT / از اول) */
  document.addEventListener("click", function (e) {
    var btn = e.target.closest ? e.target.closest("[data-go]") : null;
    if (!btn) return;
    if (btn.getAttribute("data-go") === "first") first(); else next();
  });

  /* کلیدهای جهت‌دار (دسکتاپ) */
  document.addEventListener("keydown", function (e) {
    if (e.key === "ArrowRight") next();
    else if (e.key === "ArrowLeft") goTo(current - 1);
  });

  /* Swipe چپ/راست (موبایل) */
  var sx = 0, sy = 0, tracking = false;
  document.addEventListener("touchstart", function (e) {
    if (e.touches.length !== 1) { tracking = false; return; }
    sx = e.touches[0].clientX;
    sy = e.touches[0].clientY;
    tracking = true;
  }, { passive: true });

  document.addEventListener("touchend", function (e) {
    if (!tracking) return;
    tracking = false;
    var t = e.changedTouches[0];
    var dx = t.clientX - sx;
    var dy = t.clientY - sy;
    if (Math.abs(dx) > 70 && Math.abs(dx) > Math.abs(dy) * 1.6) {
      if (dx < 0) next(); else goTo(current - 1);
    }
  }, { passive: true });

  /* ---------- Scroll reveal (صفحه «قشنگ‌ترینی») ---------- */
  function watchReveals(page) {
    if (observer) { observer.disconnect(); observer = null; }
    var items = page.querySelectorAll(".reveal:not(.in)");
    if (!items.length) return;

    if (!("IntersectionObserver" in window)) {
      Array.prototype.forEach.call(items, function (el) { el.classList.add("in"); });
      return;
    }

    observer = new IntersectionObserver(function (entries) {
      entries.forEach(function (entry) {
        if (entry.isIntersecting) {
          entry.target.classList.add("in");
          observer.unobserve(entry.target);
        }
      });
    }, { threshold: 0.35 });

    Array.prototype.forEach.call(items, function (el) { observer.observe(el); });
  }

  function resetReveals() {
    Array.prototype.forEach.call(document.querySelectorAll(".reveal.in"), function (el) {
      el.classList.remove("in");
    });
  }

  /* ---------- Music ---------- */
  var playBtn   = document.getElementById("playBtn");
  var vinyl     = document.getElementById("vinyl");
  var barFill   = document.getElementById("barFill");
  var bar       = document.getElementById("bar");
  var noteEl    = document.getElementById("musicNote");
  var audio     = null;
  var noteTimer = null;

  document.getElementById("songTitle").textContent  = SONG.title  || "Song Title";
  document.getElementById("songArtist").textContent = SONG.artist || "Artist Name";

  function setPlaying(on) {
    playBtn.classList.toggle("playing", on);
    vinyl.classList.toggle("spinning", on);
    playBtn.setAttribute("aria-label", on ? "Pause" : "Play");
  }

  function showNote(text) {
    noteEl.textContent = text;
    noteEl.hidden = false;
    clearTimeout(noteTimer);
    noteTimer = setTimeout(function () { noteEl.hidden = true; }, 3500);
  }

  function ensureAudio() {
    if (audio) return audio;
    audio = new Audio();
    audio.preload = "none";
    audio.src = SONG.src;

    audio.addEventListener("timeupdate", function () {
      if (audio.duration) barFill.style.width = (audio.currentTime / audio.duration * 100) + "%";
    });
    audio.addEventListener("ended", function () {
      setPlaying(false);
      barFill.style.width = "0";
    });
    audio.addEventListener("error", function () {
      setPlaying(false);
      showNote("فایل آهنگ پیدا نشد یا باز نشد.");
    });
    return audio;
  }

  function stopMusic() {
    if (audio) { audio.pause(); audio.currentTime = 0; }
    setPlaying(false);
    barFill.style.width = "0";
  }

  playBtn.addEventListener("click", function () {
    if (!SONG.src) {                       /* هنوز آهنگی تنظیم نشده */
      showNote("آهنگ هنوز اضافه نشده.");
      return;
    }
    var a = ensureAudio();
    if (a.paused) {
      var p = a.play();                    /* فقط با کلیک کاربر */
      if (p && p.then) {
        p.then(function () { setPlaying(true); })
         .catch(function () { setPlaying(false); showNote("پخش آهنگ ممکن نشد."); });
      } else {
        setPlaying(true);
      }
    } else {
      a.pause();
      setPlaying(false);
    }
  });

  /* کلیک روی نوار پیشرفت برای جلو/عقب بردن */
  bar.addEventListener("click", function (e) {
    if (!audio || !audio.duration) return;
    var r = bar.getBoundingClientRect();
    audio.currentTime = ((e.clientX - r.left) / r.width) * audio.duration;
  });

  /* ---------- Init ---------- */
  watchReveals(pages[0]);
})();
